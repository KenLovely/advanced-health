using UnityEngine;

namespace LivingBloodDecals
{
    public static class Mod
    {
        public static void Main() { ModAPI.Register<DecalScene>(); }
    }

    public sealed class DecalScene : MonoBehaviour
    {
        internal static bool Visible
        {
            get
            {
                var settings = UserPreferenceManager.Current;
                return settings != null && settings.Decals && !settings.GorelessMode;
            }
        }

        private void OnEnable()
        {
            ModAPI.OnItemSpawned += Spawned;
            InvokeRepeating("Discover", 0f, 8f);
        }

        private void OnDisable()
        {
            ModAPI.OnItemSpawned -= Spawned;
            CancelInvoke("Discover");
            foreach (var surface in FindObjectsOfType<BloodSurface>())
                surface.enabled = false;
        }

        private void Spawned(object sender, UserSpawnEventArgs args)
        {
            if (!args.Instance) return;
            foreach (var limb in args.Instance.GetComponentsInChildren<LimbBehaviour>())
                Prepare(limb);
        }

        // Also catches pasted contraptions, existing limbs, and non-catalog spawns.
        private void Discover()
        {
            foreach (var limb in FindObjectsOfType<LimbBehaviour>()) Prepare(limb);
        }

        private static void Prepare(LimbBehaviour limb)
        {
            if (!limb || !limb.GetComponent<PhysicalBehaviour>()) return;
            var surface = limb.GetComponent<BloodSurface>();
            if (!surface)
            {
                if (Visible) limb.gameObject.AddComponent<BloodSurface>();
            }
            else surface.enabled = Visible;
        }
    }

    [SkipSerialisation]
    public sealed class BloodSurface : MonoBehaviour
    {
        private PhysicalBehaviour receiver;
        private bool enabledDecals;
        private ContactHistory history;

        private void OnEnable()
        {
            receiver = GetComponent<PhysicalBehaviour>();
            enabledDecals = receiver && !receiver.DisplayBloodDecals;
            if (enabledDecals) receiver.DisplayBloodDecals = true;
        }

        private void OnDisable()
        {
            if (enabledDecals && receiver) receiver.DisplayBloodDecals = false;
            enabledDecals = false;
            history = new ContactHistory();
        }

        private void OnCollisionEnter2D(Collision2D hit)
        {
            if (!receiver || !receiver.DisplayBloodDecals || !DecalScene.Visible ||
                receiver.IsUnderWater || hit.contactCount == 0 || !hit.rigidbody) return;

            var source = hit.rigidbody.GetComponent<LimbBehaviour>();
            if (!source || source.gameObject == gameObject || !source.BloodDecal) return;
            var vessels = source.CirculationBehaviour;
            if (!vessels) return;
            float size = ContactHistory.MarkSize(vessels.BleedingRate, vessels.GetAmountOfBlood());
            if (size <= 0f) return;

            var point = hit.GetContact(0).point;
            var local = transform.InverseTransformPoint(point);
            if (!history.Accept(Time.time, local.x, local.y)) return;
            receiver.Decal(new DecalInstruction(source.BloodDecal, point, vessels.GetComputedColor(), size));
        }
    }
}
