using System;

namespace LivingBloodDecals
{
    // One short-lived contact record per receiving limb, in that limb's local space.
    public struct ContactHistory
    {
        private bool marked;
        private float time, x, y;

        public bool Accept(float now, float localX, float localY)
        {
            float age = now - time;
            float dx = localX - x, dy = localY - y;
            if (marked && age >= 0f && (age < 0.6f || (age < 4f && dx * dx + dy * dy < 0.0036f)))
                return false;
            marked = true;
            time = now;
            x = localX;
            y = localY;
            return true;
        }

        // Game units. An active external leak and remaining source blood are both required.
        public static float MarkSize(float bleeding, float blood)
        {
            if (!(bleeding > 0.01f && blood > 0.005f) || float.IsInfinity(bleeding) || float.IsInfinity(blood))
                return 0f;
            float wetness = Math.Min(1f, bleeding / 2f) * Math.Min(1f, blood);
            return 0.12f + 0.40f * (float)Math.Sqrt(wetness);
        }
    }
}
