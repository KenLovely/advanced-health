Pain? No Thanks! - Adjustable Relief | 3.1.1

Close People Playground and extract the PainRelief-3.1.1 folder into Mods.
Disable the original Pain? No thanks! and enable Adjustable Relief.
Load a map and spawn a new standard Human. Right-click its head and click
the Pain relief entry to cycle modes for that human. The label shows the
current mode. New Humans default to Full.

Full clears pain, shock and limb numbness. Pain only clears pain and lets the
game handle shock and numbness. Off lets the game handle all three. After
switching away from Full, new symptoms can develop normally. Previously
cleared symptoms are not reconstructed. Injuries still require treatment.
Other mods or native game effects may still produce movement or reactions.

Verified offline against Unity libraries and game API stand-ins. In-game
compilation, head-menu appearance and interactions with other mods still
require testing on the installed game.
