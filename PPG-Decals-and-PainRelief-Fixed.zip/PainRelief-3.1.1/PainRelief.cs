using UnityEngine;

namespace PainReliefMod
{
    public static class Entry
    {
        public static void Main()
        {
            var human = ModAPI.FindSpawnable("Human");
            if (!human || !human.Prefab || !human.Prefab.GetComponent<PersonBehaviour>())
            {
                Debug.LogWarning("Pain Relief: the Human prefab is unavailable.");
                return;
            }
            if (!human.Prefab.GetComponent<ReliefController>())
                human.Prefab.AddComponent<ReliefController>();
        }
    }

    public enum ReliefMode { Full, PainOnly, Off }

    public sealed class ReliefController : MonoBehaviour
    {
        public ReliefMode Mode = ReliefMode.Full;
        private PersonBehaviour person;
        private PhysicalBehaviour menuOwner;
        private ContextMenuButton menuButton;
        private float nextMenuCheck;

        private void Awake() { person = GetComponent<PersonBehaviour>(); }

        private void LateUpdate()
        {
            if (!person) return;
            if (!menuOwner && Time.unscaledTime >= nextMenuCheck)
            {
                nextMenuCheck = Time.unscaledTime + 1f;
                AttachMenu();
            }
            Apply();
        }

        private void Apply()
        {
            if (Mode == ReliefMode.Off) return;
            if (person.PainLevel != 0f) person.PainLevel = 0f;
            if (Mode != ReliefMode.Full) return;
            if (person.ShockLevel != 0f) person.ShockLevel = 0f;
            if (person.Limbs == null) return;
            foreach (var limb in person.Limbs)
            {
                if (limb && limb.Numbness != 0f) limb.Numbness = 0f;
            }
        }

        private void AttachMenu()
        {
            if (person.Limbs == null) return;
            foreach (var limb in person.Limbs)
            {
                if (!limb || !limb.HasBrain) continue;
                var physical = limb.GetComponent<PhysicalBehaviour>();
                if (!physical || physical.ContextMenuOptions == null || physical.ContextMenuOptions.Buttons == null)
                    continue;
                menuButton = new ContextMenuButton("painrelief.cycle", ModeLabel,
                    "Cycle this human through full relief, pain only, and off.", CycleMode);
                physical.ContextMenuOptions.Buttons.Add(menuButton);
                menuOwner = physical;
                return;
            }
        }

        private string ModeLabel()
        {
            switch (Mode)
            {
                case ReliefMode.Full: return "Pain relief: Full";
                case ReliefMode.PainOnly: return "Pain relief: Pain only";
                default: return "Pain relief: Off";
            }
        }

        private void CycleMode()
        {
            switch (Mode)
            {
                case ReliefMode.Full: Mode = ReliefMode.PainOnly; break;
                case ReliefMode.PainOnly: Mode = ReliefMode.Off; break;
                default: Mode = ReliefMode.Full; break;
            }
            Apply();
        }

        private void OnDisable()
        {
            if (menuOwner && menuOwner.ContextMenuOptions != null && menuOwner.ContextMenuOptions.Buttons != null)
                menuOwner.ContextMenuOptions.Buttons.Remove(menuButton);
            menuOwner = null;
            menuButton = default(ContextMenuButton);
            nextMenuCheck = 0f;
        }
    }
}
