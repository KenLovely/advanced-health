using UnityEngine;

namespace LivingBloodDecals
{
    public static class Mod
    {
        public static void Main() { ModAPI.Register<DecalScene>(); }
    }

    public sealed class DecalScene : MonoBehaviour
    {
        internal static bool Visible
        {
            get
            {
                var settings = UserPreferenceManager.Current;
                return settings != null && settings.Decals && !settings.GorelessMode;
            }
        }

        private void OnEnable()
        {
            ModAPI.OnItemSpawned += Spawned;
            InvokeRepeating("Discover", 0f, 8f);
            InvokeRepeating("DiscoverWounds", 0f, 0.8f);
        }

        private void OnDisable()
        {
            ModAPI.OnItemSpawned -= Spawned;
            CancelInvoke();
            foreach (var stream in FindObjectsOfType<LiquidStream>()) stream.enabled = false;
            foreach (var surface in FindObjectsOfType<BloodSurface>())
                surface.enabled = false;
        }

        private void Spawned(object sender, UserSpawnEventArgs args)
        {
            if (!args.Instance) return;
            foreach (var limb in args.Instance.GetComponentsInChildren<LimbBehaviour>())
                Prepare(limb);
            foreach (var outlet in args.Instance.GetComponentsInChildren<LiquidOutletBehaviour>())
                LiquidStream.Watch(outlet);
        }

        // Also catches pasted contraptions, existing limbs, and non-catalog spawns.
        private void Discover()
        {
            foreach (var limb in FindObjectsOfType<LimbBehaviour>()) Prepare(limb);
            if (Visible)
                foreach (var outlet in FindObjectsOfType<LiquidOutletBehaviour>()) LiquidStream.Watch(outlet);
        }

        private void DiscoverWounds()
        {
            if (!Visible) return;
            foreach (var wound in FindObjectsOfType<BleedingParticleBehaviour>())
                if (!wound.IsOnlyForInternalBleeding) LiquidStream.Watch(wound);
        }

        private static void Prepare(LimbBehaviour limb)
        {
            if (!limb || !limb.GetComponent<PhysicalBehaviour>()) return;
            var surface = limb.GetComponent<BloodSurface>();
            if (!surface)
            {
                if (Visible) limb.gameObject.AddComponent<BloodSurface>();
            }
            else surface.enabled = Visible;
        }
    }

    [SkipSerialisation]
    public sealed class BloodSurface : MonoBehaviour
    {
        private PhysicalBehaviour receiver;
        private bool enabledDecals;
        private ContactHistory history;
        private ContactHistory splashHistory, woundHistory;
        private LimbBehaviour limb;

        internal bool Stain(Vector2 point, Color tint, float size, bool wound)
        {
            if (!isActiveAndEnabled || !receiver || !receiver.DisplayBloodDecals ||
                receiver.IsUnderWater || !DecalScene.Visible || !limb || !limb.BloodDecal) return false;
            var local = transform.InverseTransformPoint(point);
            bool accepted = wound ? woundHistory.Accept(Time.time, local.x, local.y)
                                  : splashHistory.Accept(Time.time, local.x, local.y);
            if (!accepted) return false;
            receiver.Decal(new DecalInstruction(limb.BloodDecal, point, tint, size));
            return true;
        }

        private void OnEnable()
        {
            limb = GetComponent<LimbBehaviour>();
            receiver = GetComponent<PhysicalBehaviour>();
            enabledDecals = receiver && !receiver.DisplayBloodDecals;
            if (enabledDecals) receiver.DisplayBloodDecals = true;
        }

        private void OnDisable()
        {
            if (enabledDecals && receiver) receiver.DisplayBloodDecals = false;
            enabledDecals = false;
            history = splashHistory = woundHistory = new ContactHistory();
        }

        private void OnCollisionEnter2D(Collision2D hit)
        {
            if (!receiver || !receiver.DisplayBloodDecals || !DecalScene.Visible ||
                receiver.IsUnderWater || hit.contactCount == 0 || !hit.rigidbody) return;

            var source = hit.rigidbody.GetComponent<LimbBehaviour>();
            if (!source || source.gameObject == gameObject || !source.BloodDecal) return;
            var vessels = source.CirculationBehaviour;
            if (!vessels) return;
            float size = ContactHistory.MarkSize(vessels.BleedingRate, vessels.GetAmountOfBlood());
            if (size <= 0f) return;

            var point = hit.GetContact(0).point;
            var local = transform.InverseTransformPoint(point);
            if (!history.Accept(Time.time, local.x, local.y)) return;
            receiver.Decal(new DecalInstruction(source.BloodDecal, point, vessels.GetComputedColor(), size));
        }
    }
}
