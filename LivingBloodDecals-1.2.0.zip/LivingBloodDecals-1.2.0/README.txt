Living Blood Decals 1.2.0

Close People Playground. Move old LivingBloodDecals mod folders out of Mods.
Drag the LivingBloodDecals-1.2.0 folder directly into Mods. Restart and enable
[1.2.0] Living Blood Decals. Enable Decals and turn Goreless Mode off.

Testing on a fresh map

1. Place a limb beneath a Liquid Outlet connected to a supply of coloured
   liquid. Start a visible pour. Move the outlet sideways and watch where the
   stream crosses the limb. Place a solid board in the stream to block it.
2. Position a second human under an externally bleeding wound. Look for a
   mark on the injured limb at the wound and splashes on the limb below.
   Contact between an actively bleeding limb and a clean limb also transfers
   blood, as in 1.1.1.
3. Disable Decals, or enable Goreless Mode, and repeat with a fresh human.
   The mod should stop adding marks.

The mod samples up to eight visible drops per emitter per update. A sampled
drop stops at its first solid obstruction after leaving its source. Outlet
marks use the particle tint when present and otherwise the mixture colour.
Wound marks use the circulating liquid's colour. The game handles rendering
and cleanup. Very short bursts or dense scenes can yield fewer marks. Wounds
need an external bleeding effect. Closed bruises and internal bleeding alone
do not qualify. Modded drains need to use the game's Liquid Outlet component.

The source compiled offline with Unity assemblies and game API stand-ins.
In-game loading, appearance, particle settings and frame rate still need a
check on the installed game.
