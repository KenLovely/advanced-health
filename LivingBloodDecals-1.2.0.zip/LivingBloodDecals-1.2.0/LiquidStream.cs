using UnityEngine;

namespace LivingBloodDecals
{
    [SkipSerialisation]
    public sealed class LiquidStream : MonoBehaviour
    {
        private const int SampleCount = 8;
        private const float Interval = 0.10f;

        private struct Drop
        {
            public uint Seed;
            public float Life;
            public Vector2 Position;
            public Color Colour;
            public bool Finished;
        }

        private BleedingParticleBehaviour wound;
        private LiquidOutletBehaviour outlet;
        private ParticleSystem system;
        private ParticleSystem.Particle[] particles;
        private Drop[] previous, current;
        private int previousCount;
        private bool markedWound;
        private float nextSample;
        private static readonly RaycastHit2D[] hits = new RaycastHit2D[12];
        private static int frame, casts;

        internal static void Watch(BleedingParticleBehaviour source)
        {
            var stream = source.GetComponent<LiquidStream>();
            if (!stream) stream = source.gameObject.AddComponent<LiquidStream>();
            stream.wound = source;
            stream.enabled = true;
        }

        internal static void Watch(LiquidOutletBehaviour source)
        {
            var stream = source.GetComponent<LiquidStream>();
            if (!stream) stream = source.gameObject.AddComponent<LiquidStream>();
            stream.outlet = source;
            stream.enabled = true;
        }

        private void OnEnable()
        {
            nextSample = Time.time + ((GetInstanceID() & 31) / 32f) * Interval;
        }

        private void OnDisable()
        {
            previousCount = 0;
            markedWound = false;
            nextSample = 0f;
        }

        private void LateUpdate()
        {
            if (Time.time < nextSample) return;
            nextSample = Time.time + Interval;
            var emitter = wound ? wound.BloodParticleSystem : outlet ? outlet.LiquidParticles : null;
            if (emitter != system)
            {
                previousCount = 0;
                markedWound = false;
                system = emitter;
            }
            if (!DecalScene.Visible || !system)
            {
                previousCount = 0;
                return;
            }

            int liveDrops = system.particleCount;
            GameObject owner;
            Color tint;
            if (wound)
            {
                var vessels = wound.CirculationBehaviour;
                if (!wound.isActiveAndEnabled || wound.IsOnlyForInternalBleeding || wound.PushingTo || !vessels)
                {
                    previousCount = 0;
                    return;
                }
                if (liveDrops == 0 && (markedWound || !system.isEmitting))
                {
                    previousCount = 0;
                    return;
                }
                owner = vessels.gameObject;
                tint = vessels.GetComputedColor();
                if (!markedWound)
                {
                    float size = ContactHistory.MarkSize(vessels.BleedingRate, vessels.GetAmountOfBlood());
                    var skin = size > 0f ? owner.GetComponent<BloodSurface>() : null;
                    if (skin) markedWound = skin.Stain(wound.transform.position, tint, size, true);
                }
            }
            else
            {
                if (!outlet || !outlet.isActiveAndEnabled || liveDrops == 0)
                {
                    previousCount = 0;
                    return;
                }
                owner = outlet.gameObject;
                tint = outlet.GetComputedColor();
            }
            if (liveDrops > 0) Sample(owner, tint);
            else previousCount = 0;
        }

        private void Sample(GameObject owner, Color tint)
        {
            if (particles == null)
            {
                particles = new ParticleSystem.Particle[SampleCount];
                previous = new Drop[SampleCount];
                current = new Drop[SampleCount];
            }
            int count = system.GetParticles(particles);
            var main = system.main;
            Transform space = null;
            if (main.simulationSpace == ParticleSystemSimulationSpace.Local) space = system.transform;
            else if (main.simulationSpace == ParticleSystemSimulationSpace.Custom) space = main.customSimulationSpace;

            for (int i = 0; i < count; i++)
            {
                var particle = particles[i];
                Vector2 point = space ? space.TransformPoint(particle.position) : particle.position;
                int found = -1;
                for (int j = 0; j < previousCount; j++)
                {
                    if (previous[j].Seed == particle.randomSeed && particle.remainingLifetime <= previous[j].Life)
                    {
                        found = j;
                        break;
                    }
                }

                Drop drop;
                if (found >= 0) drop = previous[found];
                else
                {
                    // Start at the nozzle only for newborn drops. An older drop first
                    // seen beyond a wall has an unknown path and cannot safely stain.
                    Color colour = tint;
                    if (outlet)
                    {
                        // Some emitters colour each drop, others tint a white sprite.
                        Color32 emitted = particle.startColor;
                        if (emitted.r != 255 || emitted.g != 255 || emitted.b != 255)
                            colour = emitted;
                    }
                    drop = new Drop {
                        Seed = particle.randomSeed, Position = system.transform.position, Colour = colour,
                        Finished = particle.startLifetime - particle.remainingLifetime > Interval * 1.5f
                    };
                }
                if (!drop.Finished)
                    drop.Finished = Trace(drop.Position, point, owner, drop.Colour, particle.GetCurrentSize(system));
                drop.Position = point;
                drop.Life = particle.remainingLifetime;
                current[i] = drop;
            }
            var swap = previous;
            previous = current;
            current = swap;
            previousCount = count;
        }

        private static bool Trace(Vector2 start, Vector2 end, GameObject owner, Color colour, float diameter)
        {
            var delta = end - start;
            float distance = delta.magnitude;
            if (distance < 0.0001f) return false;
            if (frame != Time.frameCount) { frame = Time.frameCount; casts = 0; }
            // Retire unsampled drops on overload so they cannot mark through an obstacle.
            if (casts >= 48) return true;
            casts++;
            var filter = new ContactFilter2D { useTriggers = false };
            filter.SetLayerMask(Physics2D.DefaultRaycastLayers);
            int count = Physics2D.Raycast(start, delta / distance, filter, hits, distance);
            if (count == hits.Length) return true;
            for (int i = 0; i < count; i++)
            {
                var hit = hits[i];
                if (!hit.collider) continue;
                var body = hit.rigidbody ? hit.rigidbody.gameObject : hit.collider.gameObject;
                if (body == owner) continue;
                var skin = body.GetComponent<BloodSurface>();
                if (skin) skin.Stain(hit.point, colour, Mathf.Clamp(diameter, 0.10f, 0.36f), false);
                return true;
            }
            return false;
        }
    }
}
