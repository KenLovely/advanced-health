Living Blood Decals - Contact Transfer 1.1.1

Close People Playground. Extract the LivingBloodDecals folder into Mods.
The manifest should be at Mods/LivingBloodDecals/mod.json. Restart the game,
disable the two earlier decal mods, and enable Living Blood Decals - Contact
Transfer. Use a fresh map to test, so earlier layer and shader edits on
existing characters do not affect the result.

Turn Decals on and Goreless Mode off to see contact stains. On a fresh human,
clean limbs start clean. Move a clean limb into contact with a limb that is
visibly bleeding. Look for a small stain at the point of contact. Move apart
and touch another spot to compare. Contact marks are made when contact
begins. Contact transfer follows the reported external bleeding rate and
remaining blood, including after cauterisation. Blood already dried on a limb does not act as a new source.
The game controls ordinary splashes, decal rendering and cleanup.

The C# source compiled against Unity libraries and game API stand-ins.
Sixteen offline checks passed, including contact placement, tint, repeated
contacts and blood availability. Actual rendering and appearance on modded
creatures still require testing in People Playground.
