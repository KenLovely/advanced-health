using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using TMPro;
using Unity;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using System.Reflection;
//using Newtonsoft.Json;

namespace Mod
{

    public class Mod
    {
        internal const string PickupAction = "pickupadvanced.grabrelease";

        public static void OnLoad()
        {
            ModAPI.RegisterInput("Pickup Advanced: Pick up", PickupAction, KeyCode.R);
        }

        public static void Main()
        {
            ModAPI.OnItemSpawned += ModAPI_OnItemSpawned;
        }

        private static void ModAPI_OnItemSpawned(object sender, UserSpawnEventArgs e)
        {
            if (e.Instance.TryGetComponent<PersonBehaviour>(out PersonBehaviour personBehaviour))
            {
                foreach (var limb in personBehaviour.Limbs)
                {
                    if (limb.RoughClassification == LimbBehaviour.BodyPart.Arms && limb.gameObject.GetComponent<BetterArmToucherHuman>() == null)
                    {
                        limb.gameObject.GetOrAddComponent<BetterArmToucherHuman>();
                    }
                }
            }
        }
    }
    public class BetterArmToucherHuman : MonoBehaviour
    {
        public DragTool dragTool;
        public HingeJoint2D hingeJoint;
        public bool joined;
        public bool recoil;
        private bool waitForPickupKeyRelease;
        public Collider2D connectedCollider;
        public bool dropOnDeath;
        public Preferences preferences = null;
        public PersonBehaviour personBehaviour;
        private void Awake()
        {
            personBehaviour = gameObject.GetComponent<LimbBehaviour>().Person;
            dragTool = GameObject.FindObjectOfType<DragTool>();
            /*StreamReader streamReader = new StreamReader("config.json");
            preferences = JsonConvert.DeserializeObject<Preferences>(streamReader.ReadToEnd());*/
            //dropOnDeath = preferences.DropOnDeath;
            dropOnDeath = true;
        }
        private void Start()
        {
            hingeJoint = null;
            joined = false;
            recoil = false;
            connectedCollider = null;
        }
        private void Update()
        {
            if (waitForPickupKeyRelease && !InputSystem.Held(Mod.PickupAction))
                waitForPickupKeyRelease = false;

            joined = hingeJoint != null;
            if (!joined) return;
            if ((dropOnDeath && !personBehaviour.IsAlive()) || connectedCollider == null)
            {
                Drop();
                return;
            }

            if (!waitForPickupKeyRelease && InputSystem.Down(Mod.PickupAction) && IsReleaseTarget())
            {
                waitForPickupKeyRelease = true;
                Drop();
            }
        }

        private bool IsReleaseTarget()
        {
            if (dragTool && dragTool.ActiveSingleSelected)
                return dragTool.ActiveSingleSelected.gameObject == gameObject;

            var selection = SelectionController.Main;
            return selection != null && selection.CurrentlyUnderMouse &&
                   selection.CurrentlyUnderMouse.gameObject == gameObject;
        }

        private void Drop()
        {
            if (joined)
            {
                UnityEngine.Object.Destroy(hingeJoint);
                if (connectedCollider != null)
                {
                    Physics2D.IgnoreCollision(gameObject.GetComponent<Collider2D>(), connectedCollider, false);
                }
            }
        }
        public IEnumerator Recoil()
        {
            yield return new WaitForSeconds(1);
            recoil = false;
        }
        private void OnCollisionEnter2D(Collision2D collision2D)
        {
            if (waitForPickupKeyRelease || !InputSystem.Held(Mod.PickupAction)) return;
            if (!dragTool || !dragTool.ActiveSingleSelected || dragTool.ActiveSingleSelected.gameObject != gameObject) return;
            var grip = gameObject.GetComponent<GripBehaviour>();
            if (grip && !grip.isHolding && !recoil)
            {
                recoil = true;
                StartCoroutine(Recoil());
                if (/*collision2D.gameObject.TryGetComponent<LimbBehaviour>(out LimbBehaviour limbBehaviour) && */joined == false && collision2D.gameObject.transform.root != gameObject.transform.root)
                {//вот и всё по сути от Improved тут только замануха удачи тем англичанам кто вскрывает моды понять почему я пишу на русском а ещё ссылка лучший свервер дс https://discord.gg/xtjxX6D4ES
                    joined = true;
                    if (hingeJoint == null)
                    {
                        waitForPickupKeyRelease = true;
                        hingeJoint = gameObject.AddComponent<HingeJoint2D>();
                        hingeJoint.connectedBody = collision2D.rigidbody;
                        var point = transform.InverseTransformPoint(collision2D.contacts[0].point);
                        hingeJoint.anchor = point;
                        hingeJoint.connectedAnchor = point;
                        connectedCollider = collision2D.collider;
                        Physics2D.IgnoreCollision(gameObject.GetComponent<Collider2D>(), connectedCollider, true);
                    }
                }
            }
        }
    }
}