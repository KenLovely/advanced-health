using System.Collections;
using UnityEngine;

namespace PickupAdvancedR
{

    public class Mod
    {
        internal const string PickupAction = "pickupadvanced.grabrelease";

        public static void OnLoad()
        {
            ModAPI.RegisterInput("Pickup Advanced: Pick up", PickupAction, KeyCode.R);
        }

        internal static bool PickupKey(bool pressed)
        {
            if (DialogBox.IsAnyDialogboxOpen || Global.ActiveUiBlock) return false;
            if (InputSystem.Actions != null && InputSystem.Actions.ContainsKey(PickupAction))
                return pressed ? InputSystem.Down(PickupAction) : InputSystem.Held(PickupAction);
            return pressed ? Input.GetKeyDown(KeyCode.R) : Input.GetKey(KeyCode.R);
        }

        public static void Main()
        {
            ModAPI.OnItemSpawned -= ModAPI_OnItemSpawned;
            ModAPI.OnItemSpawned += ModAPI_OnItemSpawned;
        }

        private static void ModAPI_OnItemSpawned(object sender, UserSpawnEventArgs e)
        {
            if (e.Instance.TryGetComponent<PersonBehaviour>(out PersonBehaviour personBehaviour))
            {
                foreach (var limb in personBehaviour.Limbs)
                {
                    if (limb.RoughClassification == LimbBehaviour.BodyPart.Arms && limb.gameObject.GetComponent<BetterArmToucherHuman>() == null)
                    {
                        limb.gameObject.GetOrAddComponent<BetterArmToucherHuman>();
                    }
                }
            }
        }
    }
    public class BetterArmToucherHuman : MonoBehaviour
    {
        public DragTool dragTool;
        public HingeJoint2D hingeJoint;
        public bool joined;
        public bool recoil;
        private bool waitForPickupKeyRelease;
        public Collider2D connectedCollider;
        public bool dropOnDeath;
        public PersonBehaviour personBehaviour;
        private void Awake()
        {
            personBehaviour = gameObject.GetComponent<LimbBehaviour>().Person;
            dragTool = GameObject.FindObjectOfType<DragTool>();
            dropOnDeath = true;
        }
        private void Start()
        {
            hingeJoint = null;
            joined = false;
            recoil = false;
            connectedCollider = null;
        }
        private void Update()
        {
            if (waitForPickupKeyRelease && !Mod.PickupKey(false))
                waitForPickupKeyRelease = false;

            joined = hingeJoint != null;
            if (!joined) return;
            if ((dropOnDeath && !personBehaviour.IsAlive()) || connectedCollider == null)
            {
                Drop();
                return;
            }

            if (!waitForPickupKeyRelease && Mod.PickupKey(true) && IsTargetHand())
            {
                waitForPickupKeyRelease = true;
                Drop();
            }
        }

        private bool IsTargetHand()
        {
            if (dragTool && dragTool.ActiveSingleSelected)
                return dragTool.ActiveSingleSelected.gameObject == gameObject;

            var selection = SelectionController.Main;
            return selection != null && selection.CurrentlyUnderMouse &&
                   selection.CurrentlyUnderMouse.gameObject == gameObject;
        }

        private void Drop()
        {
            if (joined)
            {
                UnityEngine.Object.Destroy(hingeJoint);
                if (connectedCollider != null)
                {
                    Physics2D.IgnoreCollision(gameObject.GetComponent<Collider2D>(), connectedCollider, false);
                }
            }
        }
        public IEnumerator Recoil()
        {
            yield return new WaitForSeconds(1);
            recoil = false;
        }
        private void OnCollisionEnter2D(Collision2D collision2D)
        {
            TryPickup(collision2D);
        }

        private void OnCollisionStay2D(Collision2D collision)
        {
            TryPickup(collision);
        }

        private void TryPickup(Collision2D collision)
        {
            if (joined || recoil || waitForPickupKeyRelease || !Mod.PickupKey(false)) return;
            if (!IsTargetHand() || !personBehaviour.IsAlive()) return;
            if (collision.gameObject.transform.root == transform.root || collision.contactCount == 0) return;
            var grip = GetComponent<GripBehaviour>();
            if (!grip || grip.isHolding) return;

            var contact = collision.GetContact(0).point;
            hingeJoint = gameObject.AddComponent<HingeJoint2D>();
            hingeJoint.connectedBody = collision.rigidbody;
            hingeJoint.autoConfigureConnectedAnchor = false;
            hingeJoint.anchor = transform.InverseTransformPoint(contact);
            hingeJoint.connectedAnchor = collision.rigidbody
                ? (Vector2)collision.rigidbody.transform.InverseTransformPoint(contact) : contact;
            connectedCollider = collision.collider;
            Physics2D.IgnoreCollision(GetComponent<Collider2D>(), connectedCollider, true);
            joined = true;
            waitForPickupKeyRelease = true;
            recoil = true;
            StartCoroutine(Recoil());
        }
    }
}
