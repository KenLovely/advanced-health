using System;
using System.Collections.Generic;

namespace AdvancedHealth
{
    // Lives in the scene manager. No components or collision callbacks are added to a limb.
    internal sealed class Patient
    {
        private sealed class Site
        {
            public LimbBehaviour Limb;
            public CirculationBehaviour Vessels;
            public Liquid BloodType;
            public Region Region;
            public bool HeartSite, LungSite, Active;
            public float LastHealth = 1f, LastInternal, Drop, Event, Amount, LastAmount;
            public int LastWounds;
            public bool WasBroken, HasBloodSample;
        }

        public readonly PersonBehaviour Person;
        public readonly Physiology Model = new Physiology();
        private readonly Site[] sites;
        private readonly float capacity;
        public float Removed { get; private set; }
        public float Volume { get; private set; }
        public bool ExternalBleeding { get; private set; }
        public bool NativeInternalBleeding { get; private set; }
        public bool HasReading { get; private set; }

        private Patient(PersonBehaviour person, List<Site> mapped)
        {
            Person = person;
            sites = mapped.ToArray();
            capacity = sites.Length * CirculationBehaviour.ActualBloodLimit;
        }

        public static Patient TryCreate(PersonBehaviour person)
        {
            if (!person || person.Limbs == null) return null;
            Liquid humanBlood = Liquid.GetLiquid("BLOOD");
            if (humanBlood == null) return null;
            var mapped = new List<Site>();
            bool head = false, chest = false, abdomen = false, pelvis = false;
            bool hasHeart = false, hasLungs = false;
            foreach (var limb in person.Limbs)
            {
                if (!limb || !limb.CirculationBehaviour || !limb.NodeBehaviour) continue;
                if (limb.IsAndroid || limb.GetOriginalBloodType() != humanBlood) return null;
                var region = Physiology.Classify(limb.name, limb.HasBrain);
                head |= region == Region.Head;
                chest |= region == Region.Chest;
                abdomen |= region == Region.Abdomen;
                pelvis |= region == Region.Pelvis;
                bool pumpSite = limb.CirculationBehaviour.WasInitiallyPumping || limb.CirculationBehaviour.IsPump;
                hasHeart |= pumpSite;
                hasLungs |= limb.HasLungs;
                mapped.Add(new Site {
                    Limb = limb, Vessels = limb.CirculationBehaviour, Region = region,
                    HeartSite = pumpSite,
                    LungSite = limb.HasLungs, BloodType = humanBlood
                });
            }
            return head && chest && abdomen && pelvis && hasHeart && hasLungs ? new Patient(person, mapped) : null;
        }

        private static bool Finite(float value)
        {
            return !float.IsNaN(value) && !float.IsInfinity(value);
        }

        public void Tick(float dt)
        {
            if (dt <= 0f) return;
            HasReading = false;
            if (!Finite(dt) || !Finite(Person.OxygenLevel) || !Finite(Person.Consciousness)) return;
            float amount = 0f, previous = 0f, flow = 0f, pump = 0f;
            float commonDrop = 1f;
            int attached = 0, lungSites = 0;
            float workingLungs = 0f;
            ExternalBleeding = NativeInternalBleeding = false;
            foreach (var s in sites)
            {
                if (s.LungSite) lungSites++;
                var l = s.Limb;
                var c = s.Vessels;
                s.Active = l && c && l.NodeBehaviour && l.NodeBehaviour.IsConnectedToRoot && !c.IsDisconnected;
                if (!s.Active) { s.HasBloodSample = false; continue; }
                float measuredBlood = c.GetAmount(s.BloodType);
                if (!Finite(measuredBlood) || !Finite(l.Health) || !Finite(l.InitialHealth) || l.InitialHealth <= 0f ||
                    !Finite(c.BloodFlow) || !Finite(c.InternalBleedingIntensity)) return;
                attached++;
                float health = Physiology.Unit(l.Health / l.InitialHealth);
                int wounds = c.StabWoundCount + c.GunshotWoundCount;
                s.Drop = Math.Max(0f, s.LastHealth - health);
                commonDrop = Math.Min(commonDrop, s.Drop);
                float internalRise = Math.Max(0f, c.InternalBleedingIntensity - s.LastInternal);
                s.Event = Math.Max(Math.Min(0.55f, 0.18f * Math.Max(0, wounds - s.LastWounds)),
                                   Math.Min(0.4f, internalRise * 0.12f));
                if (l.Broken && !s.WasBroken) s.Event = Math.Max(s.Event, 0.15f);
                s.LastHealth = health;
                s.LastWounds = wounds;
                s.LastInternal = c.InternalBleedingIntensity;
                s.WasBroken = l.Broken;
                ExternalBleeding |= c.BleedingRate > 0.001f;
                NativeInternalBleeding |= c.InternalBleedingIntensity > 0.001f;

                s.Amount = Math.Max(0f, measuredBlood);
                amount += s.Amount;
                previous += s.HasBloodSample ? s.LastAmount : s.Amount;
                flow += Physiology.Unit(c.BloodFlow);
                if ((s.HeartSite && c.IsPump && c.GetHeartRate() > 0f) || c.ArtificialHeartbeat > 0f) pump = 1f;
                if (s.LungSite) workingLungs += l.LungsPunctured ? 0.45f : 1f;
            }

            HasReading = attached > 0;
            if (!HasReading) return;
            foreach (var s in sites)
            {
                if (!s.Active) continue;
                // Suppress shared deterioration. A native wound or new fracture remains local evidence.
                float focalDrop = Math.Max(0f, s.Drop - commonDrop);
                float hit = Math.Max(s.Event, focalDrop > 0.006f ? focalDrop : 0f);
                if (hit > 0f) Model.Injure(s.Region, s.HeartSite, s.LungSite, hit);
            }

            Model.Step(dt, amount / capacity, flow / attached, pump,
                       lungSites == 0 ? 0f : workingLungs / lungSites, Person.OxygenLevel);
            float request = Physiology.ExtraLoss(Model.LeakRate * capacity * dt, previous, amount);
            float actual = 0f;
            foreach (var s in sites)
            {
                if (!s.Active) continue;
                float lost = 0f;
                if (request > 0f && s.Amount > 0f)
                    lost = s.Vessels.RemoveLiquid(s.BloodType, request * (s.Amount / amount));
                actual += lost;
                s.LastAmount = Math.Max(0f, s.Amount - lost);
                s.HasBloodSample = true;
            }
            Removed += actual;
            Volume = Math.Max(0f, amount - actual) / capacity;
            // Only constrain a native value when the model supplies a lower ceiling.
            // The game still owns respiration, external bleeding, pumping, healing and physics.
            if (Model.Oxygen < 0.9999f && Person.OxygenLevel > Model.Oxygen) Person.OxygenLevel = Model.Oxygen;
            if (Model.ConsciousnessLimit < 1f && Person.Consciousness > Model.ConsciousnessLimit) Person.Consciousness = Model.ConsciousnessLimit;
        }
    }
}
