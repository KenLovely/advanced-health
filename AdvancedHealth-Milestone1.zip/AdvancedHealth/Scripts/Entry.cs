using System.Collections.Generic;
using UnityEngine;

namespace AdvancedHealth
{
    public class Entry
    {
        internal const string InspectKey = "advancedhealth.inspect";
        public static void OnLoad() { ModAPI.RegisterInput("Medical inspector", InspectKey, KeyCode.F8); }
        public static void Main() { ModAPI.Register<HealthMonitor>(); }
    }

    public sealed class HealthMonitor : MonoBehaviour
    {
        private readonly List<Patient> patients = new List<Patient>();
        private readonly Dictionary<PersonBehaviour, Patient> byPerson = new Dictionary<PersonBehaviour, Patient>();
        private readonly List<PersonBehaviour> pending = new List<PersonBehaviour>();
        private Patient selected;
        private MedicalInspector inspector;
        private float elapsed, nextDiscovery, nextDisplay;

        private void OnEnable() { ModAPI.OnItemSpawned += OnSpawn; }
        private void OnDisable()
        {
            ModAPI.OnItemSpawned -= OnSpawn;
            Close();
        }

        private void OnDestroy() { if (inspector != null) inspector.ReleaseFont(); }

        private void OnSpawn(object sender, UserSpawnEventArgs args)
        {
            if (!args.Instance) return;
            var person = args.Instance.GetComponent<PersonBehaviour>();
            if (person) pending.Add(person);
        }

        private Patient Track(PersonBehaviour person)
        {
            if (!person) return null;
            Patient patient;
            if (byPerson.TryGetValue(person, out patient)) return patient;
            patient = Patient.TryCreate(person);
            if (patient != null)
            {
                patients.Add(patient);
                byPerson.Add(person, patient);
            }
            return patient;
        }

        private void Update()
        {
            elapsed += Time.deltaTime;
            if (elapsed >= 0.25f)
            {
                // Catch pasted contraptions and spawns from mods that skip the catalog event.
                if (Time.time >= nextDiscovery)
                {
                    nextDiscovery = Time.time + 8f;
                    foreach (var person in FindObjectsOfType<PersonBehaviour>()) Track(person);
                }
                foreach (var person in pending) Track(person);
                pending.Clear();
                for (int i = patients.Count - 1; i >= 0; i--)
                {
                    var p = patients[i];
                    if (p.Person)
                    {
                        if (p.Person.isActiveAndEnabled) p.Tick(elapsed);
                    }
                    else
                    {
                        byPerson.Remove(p.Person);
                        patients.RemoveAt(i);
                    }
                }
                elapsed = 0f;
            }

            if (InputSystem.Down(Entry.InspectKey))
            {
                var hovered = SelectionController.Main == null ? null : SelectionController.Main.CurrentlyUnderMouse;
                var limb = hovered ? hovered.GetComponent<LimbBehaviour>() : null;
                var target = limb ? Track(limb.Person) : null;
                if (target == null || target == selected)
                {
                    if (selected == null && target == null) ModAPI.Notify("Hover over a human to inspect.");
                    Close();
                }
                else
                {
                    selected = target;
                    if (inspector == null) inspector = new MedicalInspector(transform);
                    nextDisplay = 0f;
                }
            }
            if (selected != null)
            {
                if (!selected.Person || !selected.Person.isActiveAndEnabled) Close();
                else if (Time.unscaledTime >= nextDisplay)
                {
                    inspector.Show(selected);
                    nextDisplay = Time.unscaledTime + 0.25f;
                }
            }
        }

        private void Close()
        {
            selected = null;
            if (inspector != null) inspector.Hide();
        }
    }
}
