using System;

namespace AdvancedHealth
{
    public enum Region { Extremity, Head, Chest, Abdomen, Pelvis }

    // Scalars use fractions of healthy capacity. Time is measured in simulation seconds.
    public sealed class Physiology
    {
        public float Brain = 1f, Heart = 1f, Lungs = 1f, Liver = 1f, Kidneys = 1f;
        public float Blood { get; private set; }
        public float Pump { get; private set; }
        public float Pressure { get; private set; }
        public float Ventilation { get; private set; }
        public float Oxygen { get; private set; }
        public float Delivery { get; private set; }
        public float ConsciousnessLimit { get; private set; }
        public float LeakRate { get; private set; }
        private float wound, oxygenReserve = 1f, oxygenDebt;

        public static float Unit(float x) { return Math.Min(1f, Math.Max(0f, x)); }

        public static Region Classify(string name, bool hasBrain)
        {
            if (hasBrain || name == "Head") return Region.Head;
            if (name == "UpperBody") return Region.Chest;
            if (name == "MiddleBody") return Region.Abdomen;
            if (name == "LowerBody") return Region.Pelvis;
            return Region.Extremity;
        }

        // Pump and lung flags follow the prefab. A limb can carry both.
        public void Injure(Region region, bool pumpSite, bool lungSite, float severity)
        {
            float hit = Unit(severity);
            if (pumpSite) Heart = Unit(Heart - 0.90f * hit);
            if (lungSite) Lungs = Unit(Lungs - 0.95f * hit);
            float bleeding = 0.003f;
            switch (region)
            {
                case Region.Head:
                    Brain = Unit(Brain - hit);
                    bleeding = 0.005f;
                    break;
                case Region.Chest:
                    bleeding = 0.023f;
                    break;
                case Region.Abdomen:
                    Liver = Unit(Liver - 0.95f * hit);
                    Kidneys = Unit(Kidneys - 0.45f * hit);
                    bleeding = 0.032f;
                    break;
                case Region.Pelvis:
                    Kidneys = Unit(Kidneys - 0.55f * hit);
                    bleeding = 0.018f;
                    break;
            }
            wound = Math.Min(0.06f, wound + hit * bleeding);
        }

        public void Step(float dt, float blood, float nativeFlow, float pumpSupport,
                         float lungAvailability, float nativeOxygen)
        {
            if (dt <= 0f) return;
            Blood = Unit(blood);
            Pump = Heart * Unit(pumpSupport);
            Pressure = Unit(Pump * Unit(nativeFlow) * Blood);
            Ventilation = Lungs * Unit(lungAvailability);
            // A reserve delays desaturation. Native drowning or other native deficits take precedence.
            float response = 1f - (float)Math.Exp(-dt / 5f);
            oxygenReserve += (Ventilation - oxygenReserve) * response;
            Oxygen = Math.Min(Unit(nativeOxygen), oxygenReserve);
            Delivery = Oxygen * Pressure;
            float deficit = Math.Max(0f, 0.50f - Delivery);
            oxygenDebt = Unit(oxygenDebt + dt * (deficit * 0.12f - Math.Max(0f, Delivery - 0.50f) * 0.18f));
            ConsciousnessLimit = Unit(Math.Min(Brain * 1.45f, 1f - oxygenDebt));

            // Prolonged severe oxygen debt causes secondary injury, independent of local trauma.
            float secondary = Math.Max(0f, oxygenDebt - 0.60f) * deficit * dt;
            Brain = Unit(Brain - secondary * 0.028f);
            Kidneys = Unit(Kidneys - secondary * 0.016f);
            Liver = Unit(Liver - secondary * 0.008f);

            // Wounds close more slowly with liver damage. Reduced pressure slows extravasation.
            LeakRate = wound * Pressure;
            wound *= (float)Math.Exp(-dt * (0.009f + Liver * 0.026f));
            if (wound < 0.00001f) wound = 0f;
        }

        // Credit observed native losses first. The caller records the post-withdrawal native
        // volume as the baseline for the next tick, so our own debit is never credited twice.
        public static float ExtraLoss(float expected, float before, float current)
        {
            float alreadyLost = Math.Max(0f, before - current);
            return Math.Min(current, Math.Max(0f, expected - alreadyLost));
        }
    }
}
