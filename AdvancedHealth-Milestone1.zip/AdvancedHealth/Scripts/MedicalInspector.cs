using System.Text;
using UnityEngine;
using UnityEngine.UI;

namespace AdvancedHealth
{
    internal sealed class MedicalInspector
    {
        private readonly GameObject canvasObject;
        private readonly Text text;
        private readonly Font font;
        private readonly StringBuilder lines = new StringBuilder(560);

        public MedicalInspector(Transform parent)
        {
            canvasObject = new GameObject("Advanced Health inspector", typeof(RectTransform), typeof(Canvas), typeof(CanvasScaler));
            canvasObject.transform.SetParent(parent, false);
            var canvas = canvasObject.GetComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            canvas.sortingOrder = 80;
            var scaler = canvasObject.GetComponent<CanvasScaler>();
            scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            scaler.referenceResolution = new Vector2(1280, 720);
            scaler.matchWidthOrHeight = 0.5f;
            var panel = new GameObject("Medical readings", typeof(RectTransform), typeof(Image));
            panel.transform.SetParent(canvasObject.transform, false);
            var rect = panel.GetComponent<RectTransform>();
            rect.anchorMin = rect.anchorMax = rect.pivot = new Vector2(1, 1);
            rect.anchoredPosition = new Vector2(-16, -52);
            rect.sizeDelta = new Vector2(315, 430);
            var image = panel.GetComponent<Image>();
            image.color = new Color(0.055f, 0.08f, 0.09f, 0.96f);
            image.raycastTarget = false;
            var label = new GameObject("Readings", typeof(RectTransform), typeof(Text));
            label.transform.SetParent(panel.transform, false);
            var area = label.GetComponent<RectTransform>();
            area.anchorMin = Vector2.zero;
            area.anchorMax = Vector2.one;
            area.offsetMin = new Vector2(14, 8);
            area.offsetMax = new Vector2(-12, -10);
            text = label.GetComponent<Text>();
            font = Font.CreateDynamicFontFromOSFont("Arial", 16);
            text.font = font;
            text.fontSize = 16;
            text.lineSpacing = 1f;
            text.supportRichText = true;
            text.color = Color.white;
            text.alignment = TextAnchor.UpperLeft;
            text.raycastTarget = false;
        }

        public void Hide() { canvasObject.SetActive(false); }
        public void ReleaseFont() { if (font) Object.Destroy(font); }

        private void Row(string label, float value)
        {
            lines.Append(label).Append("   ").Append(Mathf.RoundToInt(value * 100f)).AppendLine("%");
        }

        public void Show(Patient patient)
        {
            canvasObject.SetActive(true);
            lines.Length = 0;
            lines.AppendLine("<b>MEDICAL INSPECTOR</b>");
            lines.Append("Human #").AppendLine(patient.Person.GetInstanceID().ToString());
            if (patient.HasReading)
            {
                var m = patient.Model;
                lines.AppendLine("<color=#9BE3CA>ORGAN HEALTH</color>");
                Row("Brain", m.Brain); Row("Heart", m.Heart); Row("Lungs", m.Lungs);
                Row("Liver", m.Liver); Row("Kidneys", m.Kidneys);
                lines.AppendLine("<color=#9BE3CA>CIRCULATION & RESPIRATION</color>");
                Row("Circulating blood", patient.Volume); Row("Pump function", m.Pump);
                Row("Relative pressure", m.Pressure); Row("Ventilation", m.Ventilation);
                Row("Oxygen", m.Oxygen); Row("Oxygen delivery", m.Delivery);
                lines.Append("Organ/tissue leak   ").Append((m.LeakRate * 100f).ToString("0.00")).AppendLine("%/s");
                lines.Append("Extra blood lost   ").Append(patient.Removed.ToString("0.00")).AppendLine(" units");
                lines.Append("Native internal bleed   ").AppendLine(patient.NativeInternalBleeding ? "Yes" : "No");
                lines.Append("External bleed   ").AppendLine(patient.ExternalBleeding ? "Yes" : "No");
            }
            else lines.AppendLine("Waiting for valid circulation readings.");
            lines.Append("<color=#A9B7B9>Inspect again to close</color>");
            text.text = lines.ToString();
        }
    }
}
