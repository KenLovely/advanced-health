using System;
using System.Diagnostics;
using AdvancedHealth;

public static class MilestoneTests
{
    const float Dt = 0.25f;
    static int count;
    static void Verify(string label, bool ok)
    {
        if (!ok) throw new Exception(label);
        count++;
        Console.WriteLine("PASS  " + label);
    }
    static bool Near(float a, float b) { return Math.Abs(a - b) < 0.0001f; }
    static PersonBehaviour Human()
    {
        var p = new PersonBehaviour();
        string[] names = { "Head", "UpperBody", "MiddleBody", "LowerBody", "LowerArm" };
        p.Limbs = new LimbBehaviour[names.Length];
        for (int i = 0; i < names.Length; i++)
        {
            p.Limbs[i] = new LimbBehaviour {
                Person = p, name = names[i], HasBrain = i == 0, HasLungs = i == 1,
                CirculationBehaviour = new CirculationBehaviour { IsPump = i == 1, WasInitiallyPumping = i == 1 },
                NodeBehaviour = new ConnectedNodeBehaviour()
            };
        }
        return p;
    }
    static void Step(Patient p, int ticks)
    {
        for (int i = 0; i < ticks; i++) p.Tick(Dt);
    }
    static void Main()
    {
        var owner = Human();
        var p = Patient.TryCreate(owner);
        Step(p, 240);
        Verify("Healthy for 60 seconds", p.HasReading && Near(p.Volume, 1) && Near(p.Model.Delivery, 1) && Near(p.Removed, 0));
        owner.OxygenLevel = 0.2f; owner.Consciousness = 0.1f;
        Step(p, 1);
        Verify("Native deficits respected", Near(p.Model.Oxygen, 0.2f) && Near(owner.Consciousness, 0.1f));
        owner = Human(); p = Patient.TryCreate(owner);
        owner.Limbs[4].Health = 25;
        Step(p, 1);
        Verify("Isolated arm trauma spares organs", Near(p.Model.Heart + p.Model.Lungs + p.Model.Liver + p.Model.Kidneys + p.Model.Brain, 5));
        Verify("Closed tissue injury can bleed internally", p.Removed > 0f && !p.ExternalBleeding);

        owner = Human(); p = Patient.TryCreate(owner);
        owner.Limbs[0].Health = 30; Step(p, 1);
        Verify("Head trauma localizes to brain and limits consciousness", Near(p.Model.Brain, 0.3f) && Near(p.Model.Heart, 1) && owner.Consciousness < 0.5f);
        owner = Human(); p = Patient.TryCreate(owner);
        owner.Limbs[1].Health = 30; Step(p, 1);
        float firstOxygen = p.Model.Oxygen, heart = p.Model.Heart;
        Verify("Chest injury reduces pumping and ventilation", heart < 0.5f && p.Model.Ventilation < 0.5f && p.Model.Pressure < 0.5f);
        Step(p, 40);
        Verify("Oxygen reserve depletes over time", p.Model.Oxygen < firstOxygen - 0.4f && Near(owner.OxygenLevel, p.Model.Oxygen));
        Verify("Persistent wound does not replay the initial trauma", Near(heart, p.Model.Heart));
        Verify("Heart and lung injury impair systemic oxygen delivery", p.Model.Delivery < 0.25f && owner.Consciousness < 1f);

        owner = Human(); p = Patient.TryCreate(owner);
        owner.Limbs[2].Health = 40;
        Step(p, 1);
        Verify("Abdominal trauma affects liver and kidneys", p.Model.Liver < p.Model.Kidneys && p.Model.Kidneys < 1 && p.Model.Lungs == 1);
        float loss = p.Removed;
        float sum = 0f;
        foreach (var limb in owner.Limbs) sum += limb.CirculationBehaviour.Blood;
        Verify("Actual withdrawal conserves mass", Near(5f - sum, loss) && Near(p.Volume, sum / 5f));
        Verify("Non-blood liquid untouched", Near(owner.Limbs[0].CirculationBehaviour.OtherFluid, 0.2f));
        owner.Limbs[2].CirculationBehaviour.Blood -= 0.1f;
        owner.Limbs[2].CirculationBehaviour.BleedingRate = 0.2f;
        Step(p, 1);
        Verify("Native loss credited once", p.ExternalBleeding && Near(p.Removed, loss));
        Step(p, 1);
        Verify("Open leak resumes withdrawal next tick", p.Removed > loss);
        float before = p.Volume;
        owner.Limbs[2].CirculationBehaviour.Blood += 0.1f;
        Step(p, 1);
        Verify("Transfused blood enters circulation", p.Volume > before);
        owner.Limbs[4].NodeBehaviour.IsConnectedToRoot = false;
        float armBlood = owner.Limbs[4].CirculationBehaviour.Blood;
        before = p.Volume; Step(p, 8);
        Verify("Detached blood excluded from volume and withdrawal", Near(owner.Limbs[4].CirculationBehaviour.Blood, armBlood) && p.Volume < before - 0.15f);

        owner = Human(); p = Patient.TryCreate(owner);
        foreach (var limb in owner.Limbs) limb.Health = 50f;
        Step(p, 1);
        Verify("Uniform health decay is not five focal impacts", p.Model.Liver == 1 && p.Model.Heart == 1 && p.Removed == 0f);
        owner.Limbs[3].CirculationBehaviour.InternalBleedingIntensity = 1;
        Step(p, 1);
        float kidneys = p.Model.Kidneys;
        Step(p, 2);
        Verify("New local internal bleed counted once", p.NativeInternalBleeding && kidneys < 1 && Near(kidneys, p.Model.Kidneys));
        owner.Limbs[1].LungsPunctured = true; Step(p, 4);
        Verify("Native puncture lowers ventilation", p.Model.Ventilation < 0.5f);
        owner.Limbs[1].LungsPunctured = false; owner.OxygenLevel = 1f; Step(p, 1);
        Verify("Native lung repair releases ventilation limit", Near(p.Model.Ventilation, 1));
        owner.Limbs[1].CirculationBehaviour.IsPump = false; Step(p, 4);
        Verify("Native cardiac arrest stops perfusion", p.Model.Pressure == 0 && p.Model.Delivery == 0);
        owner.Limbs[1].CirculationBehaviour.ArtificialHeartbeat = 60; Step(p, 1);
        Verify("Artificial pulse restores supported flow", p.Model.Pressure > 0.9f);

        owner = Human(); owner.Limbs[0].IsAndroid = true;
        Verify("Android excluded", Patient.TryCreate(owner) == null);
        owner = Human(); owner.Limbs[1].HasLungs = false;
        Verify("Unrecognized anatomy excluded", Patient.TryCreate(owner) == null);
        Verify("Loss bounded at empty or depleted reservoir", Near(Physiology.ExtraLoss(2, 0, 0), 0) && Near(Physiology.ExtraLoss(2, 0.1f, 0.1f), 0.1f));
        var sim = new Physiology();
        for (int i = 0; i < 400; i++) sim.Step(Dt, 0f, 0f, 0f, 0f, 0f);
        Verify("Prolonged oxygen debt injures brain and kidneys", sim.Brain < 0.7f && sim.Kidneys < 0.9f && sim.ConsciousnessLimit == 0f);
        var isolated = Patient.TryCreate(Human());
        isolated.Tick(Dt);
        Verify("Separate patients have independent state", isolated.Model.Brain == 1 && isolated.Removed == 0);

        owner = Human(); p = Patient.TryCreate(owner);
        var vessel = owner.Limbs[2].CirculationBehaviour;
        vessel.BloodFlow = float.NaN;
        Step(p, 1);
        Verify("Malformed native sample causes no write", !p.HasReading && p.Removed == 0 && owner.OxygenLevel == 1);
        vessel.BloodFlow = 1; Step(p, 1);
        Verify("Valid readings resume after malformed input", p.HasReading && Near(p.Model.Delivery, 1));
        owner.Limbs[1].CirculationBehaviour.GunshotWoundCount = 1;
        p.Tick(0);
        Verify("Zero simulation time pauses injuries", p.Model.Heart == 1f);
        Step(p, 1);
        Verify("A new wound registers without a health delta", p.Model.Heart < 1f && p.Removed > 0);
        float leakAtStart = p.Model.LeakRate;
        Step(p, 120);
        Verify("Leak subsides as wounds clot", p.Model.LeakRate < leakAtStart * 0.5f);

        var crowd = new Patient[100];
        for (int i = 0; i < crowd.Length; i++)
        {
            var human = Human();
            crowd[i] = Patient.TryCreate(human);
            human.Limbs[2].Health = 75f;
        }
        var clock = Stopwatch.StartNew();
        for (int i = 0; i < 400; i++) foreach (var patient in crowd) patient.Tick(Dt);
        clock.Stop();
        Console.WriteLine(count + " checks passed. 40,000 five-site fixture ticks in " + clock.ElapsedMilliseconds + " ms.");
    }
}
