// Offline test fixtures only. This file must never appear in mod.json.
using System;
using System.Collections.Generic;
#if UNITY_REFS
using Behaviour = UnityEngine.MonoBehaviour;
#else
public class Behaviour
{
    public string name;
    public static implicit operator bool(Behaviour value) { return value != null; }
}
#endif

public class Liquid
{
    private static readonly Liquid Blood = new Liquid();
    public static Liquid GetLiquid(string id) { return id == "BLOOD" ? Blood : null; }
}

public class ConnectedNodeBehaviour : Behaviour { public bool IsConnectedToRoot = true; }
public class LimbBehaviour : Behaviour
{
    public ConnectedNodeBehaviour NodeBehaviour;
    public CirculationBehaviour CirculationBehaviour;
    public PersonBehaviour Person;
    public Liquid Original = Liquid.GetLiquid("BLOOD");
    public float Health = 100f, InitialHealth = 100f;
    public bool IsAndroid, HasBrain, HasLungs, LungsPunctured, Broken;
    public Liquid GetOriginalBloodType() { return Original; }
}
public class PersonBehaviour : Behaviour
{
    public LimbBehaviour[] Limbs;
    public float OxygenLevel = 1f, Consciousness = 1f;
}
public class CirculationBehaviour : Behaviour
{
    public const float ActualBloodLimit = 1f;
    public bool IsDisconnected, WasInitiallyPumping, IsPump;
    public ushort StabWoundCount, GunshotWoundCount;
    public float InternalBleedingIntensity, BleedingRate, BloodFlow = 1f, ArtificialHeartbeat;
    public float Blood = 1f, OtherFluid = 0.2f;
    public float GetHeartRate() { return IsPump ? 70f : 0f; }
    public float GetAmount(Liquid type) { return type == Liquid.GetLiquid("BLOOD") ? Blood : OtherFluid; }
    public float RemoveLiquid(Liquid type, float requested)
    {
        if (type != Liquid.GetLiquid("BLOOD")) throw new Exception("Non-blood liquid requested");
        float actual = Math.Min(Blood, requested);
        Blood -= actual;
        return actual;
    }
}

#if UNITY_REFS
public class PhysicalBehaviour : Behaviour {}
public class UserSpawnEventArgs : EventArgs { public readonly UnityEngine.GameObject Instance; }
public class SelectionController
{
    public static SelectionController Main { get; private set; }
    public PhysicalBehaviour CurrentlyUnderMouse { get; private set; }
}
public static class InputSystem { public static bool Down(string id) { return false; } }
public static class ModAPI
{
    public static event EventHandler<UserSpawnEventArgs> OnItemSpawned { add {} remove {} }
    public static void Register<T>() where T : Behaviour {}
    public static void RegisterInput(string name, string id, UnityEngine.KeyCode key) {}
    public static void Notify(object obj) {}
}
#endif
