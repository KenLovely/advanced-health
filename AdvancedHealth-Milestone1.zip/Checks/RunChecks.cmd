@echo off
setlocal
set "compiler=%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
if not exist "%compiler%" set "compiler=%SystemRoot%\Microsoft.NET\Framework\v4.0.30319\csc.exe"
if not exist "%compiler%" (
    echo The .NET Framework 4.x C# compiler is required for the offline tests.
    exit /b 1
)
set "build=%TEMP%\advanced-health-check-%RANDOM%-%RANDOM%"
mkdir "%build%" || exit /b 1
"%compiler%" /nologo /target:exe /out:"%build%\Tests.exe" "%~dp0GameDoubles.cs" "%~dp0MilestoneTests.cs" "%~dp0..\AdvancedHealth\Scripts\Physiology.cs" "%~dp0..\AdvancedHealth\Scripts\Patient.cs"
if errorlevel 1 exit /b 1
"%build%\Tests.exe"
set "result=%ERRORLEVEL%"
del "%build%\Tests.exe"
rmdir "%build%"
exit /b %result%
