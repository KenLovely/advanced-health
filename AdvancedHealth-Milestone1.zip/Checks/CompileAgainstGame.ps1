# Optional Windows check. Reads installed assemblies and compiles the manifest files to TEMP.
param([Parameter(Mandatory=$true)][string] $GameFolder)
$ErrorActionPreference = 'Stop'
$managed = Join-Path $GameFolder 'People Playground_Data\Managed'
$mod = Join-Path $PSScriptRoot '..\AdvancedHealth'
if (!(Test-Path -LiteralPath (Join-Path $managed 'Assembly-CSharp.dll'))) {
    throw "No Assembly-CSharp.dll in $managed"
}
$csc = @("$env:SystemRoot\Microsoft.NET\Framework64\v4.0.30319\csc.exe",
         "$env:SystemRoot\Microsoft.NET\Framework\v4.0.30319\csc.exe") |
    Where-Object { Test-Path -LiteralPath $_ } | Select-Object -First 1
if (!$csc) { throw 'The .NET Framework 4.x C# compiler is required for this optional check.' }
$manifest = Get-Content -Raw -LiteralPath (Join-Path $mod 'mod.json') | ConvertFrom-Json
$sources = @($manifest.Scripts | ForEach-Object { Join-Path $mod $_ })
$references = @(Get-ChildItem -LiteralPath $managed -Filter '*.dll' -File | ForEach-Object {
    try {
        [void][Reflection.AssemblyName]::GetAssemblyName($_.FullName)
        "/reference:$($_.FullName)"
    } catch [System.BadImageFormatException] {
        # Skip native DLLs when a distribution keeps them in Managed.
    }
})
$output = Join-Path ([IO.Path]::GetTempPath()) ("AdvancedHealth-" + [guid]::NewGuid() + ".dll")
& $csc /nologo /noconfig /nostdlib /target:library "/out:$output" @references @sources
if ($LASTEXITCODE -ne 0) { throw "Compile against installed game assemblies failed ($LASTEXITCODE)." }
Write-Host "Compiled the manifest sources against local game assemblies: $output"
